package com.atendopro.api.dto.payment;

import jakarta.validation.constraints.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

@Getter
@Setter
public class PaymentRequest {
    @NotNull
    private UUID appointmentId;
    @NotNull
    @DecimalMin("0.0")
    private BigDecimal amount;
    private String method;
    private LocalDate dueDate;
}